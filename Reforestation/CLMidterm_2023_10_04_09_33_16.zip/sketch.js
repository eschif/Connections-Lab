let deforestMap;

function preload() {
  deforestMap = loadImage('deforestmap.png');
        }

//set up the canvas, this section runs once at the beginning
function setup() {
  //set the dimensions of the canvas to be the same as whatever the window's dimensions happen to be at the moment the code is run
  createCanvas(windowWidth, windowHeight);
  //any shapes or lines or other forms on this canvas default to have no outline/stroke
  noStroke();
  //leave the setup block
  image(deforestMap, 0, 0);
}

//open up the draw loop, a new function, runs 60 frames per second, looping continuously
function draw() {
  //set the background to an almost white color, this is revealed around the mouse l8a
  background(220, 0);
  image(deforestMap, 0, 0);
  //create a for loop that fills the canvas with circles. The outer loop goes through all the x values on the canvas, setting the circles at increments of 20 along the x-axis. If I were to rewrite this I would add an "or equal to" to the exit conditions of each loop to avoid the big white space when mousing over the bottom and right edges of the canvas.
  for (let x = 0; x < width; x += 10) {
    //the inner loop accounts for all of the y values for our circles, placing them from 0 until the end of the canvas (height) by increments of 20
    for (let y = 0; y < height; y += 10) {
      //as each circle is plotted at each x and y coordinate, each spaced out by 20 pixels horizontally and vertically, we create a variable d to store the value of the distance between each circle's center point to the coordinates of the mouse. this variable d changes depending on where the mouse is in relation to each circle, meaning that each circle has its own unique distance to the mouse and therefore has a d value that is unique to it and the other surrounding circles that are equidistant to the mouse's x,y position
      let d = dist(x, y, mouseX, mouseY);
      //we fill each circle with rgb values that are dependent upon their different d values and their specific x, y positions. So the amount of red for a given circle's fill color is their distance from the mouse divided by 5, which explains why we see red (circles) only at great distances from the mouse, as only large d values divided by 5 will yield a high value for the r (red) of the fill. The change in the d variable is the only change dependent on the mouse's position, so the change in color we detect around the canvas is due to this r value and not to the g or b values. The g value is determined by the x position of a given circle's centerpoint, divided by 5, meaning that the farther right a circle is on the canvas, the higher its x value and therefore its x value dividede by 5 yields a greater g value, resulting in more green in that circle's fill. This accounts for the right side of the canvas showing green far more than the left side of the canvas. The b value is determined by the y value of a given circle's centerpoint, divided by 5. So as we get higher y values, or closer to the bottom of the canvas, we have greater b values, resulting in more blue towards the bottom of the canvas and little to no blue at the top of the canvas.
      fill(0, 0, 0, d/2);
      //Lastly, the circles are plotted using each x and y value that the for loop brings us to. The last argument of the circle is the diameter, which is the distance between the circle being plotted to the mouse's position, divided by 8. circles close to the mouse will have a very low d value, so when that is divided by 8 the diameter is super short. Circles far from the mouse will have a greater d value, so when d is divided by 8, the diameter of those further circles grows longer, eventually touching the circles surrounding it and creating an effect of continuous filled color. If we were to have a stroke we could see this is just an illusion and the screen is actually filled with circles of differing diameters and colors and positions. The little chunks of color don't look circular because the circles are being plotted in order from top to bottom and left to right, overlapping each other to form a more fish-scale-y pattern.
      circle(x, y, d / 1.2);
      //close the inner for loop
    }
    //close the outer for loop
  }
  //close the draw loop
}









